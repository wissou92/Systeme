/*typedef struct {
	int * teamID;
	int nbJoueur;
} team_t;

// Intialise les deux equipes
//\param							nmap			carte navale
//\param							team1			equipe 1
//\param							team2			equipe 2
void init_team (navalmap_t * nmap, team_t * team1, team_t * team2);

// Désalloue la mémoire des équipes
//\param							team1			equipe 1
//\param							team2			equipe 2
void free_team (team_t * team1, team_t * team2);

// Algorithme de décision pour le matchmaking par équipe
//\param							nmap			carte navale
void deathmatch (navalmap_t * nmap);

// Execute la fonction appropriée aux threads
//\param							indice			indice du thread
//\return											le retour du tread
int thread_function (int indice);
*/
